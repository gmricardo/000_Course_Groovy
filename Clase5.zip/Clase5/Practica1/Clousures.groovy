def MetodoList(miClousure){
    def list = [1, 2, 3, 4, 5];
    list.collect(miClousure);
}

def MetodoMap(miClousure){
    def mapa = [id:123, nombres: 'Ricardo', apellidos: 'Garzón Medina']
    mapa.collect(miClousure);
}

miClosure = { println it }

MetodoList(miClosure)
println("______________________________")
MetodoMap(miClosure)

